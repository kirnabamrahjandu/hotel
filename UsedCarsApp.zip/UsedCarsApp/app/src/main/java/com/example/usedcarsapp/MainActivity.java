package com.example.usedcarsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    ArrayList<String>makes = new ArrayList<>();
    ArrayList<Integer>years=new ArrayList<>();
    ArrayList<String>carNames=new ArrayList<>();
    ArrayList<Car>carList=new ArrayList<>();
    Spinner makeSP,yearSP,carSP;
    ImageView img1,img2,img3,img4,img5;
    TextView price,millage,noCars,priceLabel,millageLable, carsLabel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fillingData();

        makeSP=findViewById(R.id.spMake);
        yearSP=findViewById(R.id.spYear);
        carSP=findViewById(R.id.spCars);
        img1=findViewById(R.id.imgMain);
        img2=findViewById(R.id.imgSide1);
        img3=findViewById(R.id.imgSide2);
        img4=findViewById(R.id.imgSide3);
        img5=findViewById(R.id.imgSide4);
        price=findViewById(R.id.txtPrice);
        millage=findViewById(R.id.txtMillage);
        noCars=findViewById(R.id.txtNoCars);
        priceLabel=findViewById(R.id.textView5);
        millageLable=findViewById(R.id.textView7);
        carsLabel=findViewById(R.id.textView4);

        ArrayAdapter makeAdapter = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,makes);
        makeSP.setAdapter(makeAdapter);

        ArrayAdapter yearAdapter = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,years);
        yearSP.setAdapter(yearAdapter);

        yearSP.setOnItemSelectedListener(this);
    }
    public void fillingData(){
        makes.add("Audi");
        makes.add("BMW");
        makes.add("Ford");
        makes.add("Huyndai");
        makes.add("Nissan");

        years.add(2020);
        years.add(2019);
        years.add(2018);
        ArrayList<String>images=new ArrayList<>();
        images.add("audi1");
        images.add("audi2");
        images.add("audi3");
        images.add("audi4");
        images.add("audi5");

        Car car = new Car("Audi","Q7",2020,45000,102000,images);
        carList.add(car);
        images.clear();
        images.add("huyndai1");
        images.add("huyndai2");
        images.add("huyndai3");
        car = new Car("Huyndai","Alantra",2019,145000,17000,images);
        carList.add(car);

    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        if(adapterView.getId()==R.id.spYear){
            carNames.clear();
            fillCarNames(makeSP.getSelectedItem().toString(),years.get(i));
            if(carNames.size()>0) {
                casrAvailable();
                ArrayAdapter carAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, carNames);
                carSP.setAdapter(carAdapter);
                Car obj = getCarObject(carSP.getSelectedItem().toString());
                price.setText(String.valueOf(obj.getPrice()));
                millage.setText(String.valueOf(obj.getMillage()));

            }
            else
                noCarsAvailable();

        }
        else if(adapterView.getId()==R.id.spCars){
            Car obj = getCarObject(carNames.get(i));
            price.setText(String.valueOf(obj.getPrice()));
            millage.setText(String.valueOf(obj.getMillage()));
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
    public void fillCarNames(String make,int year){
        for(int i=0;i<carList.size();i++)
            if(carList.get(i).getCarMake().equals(make) && carList.get(i).getYear()==year)
                carNames.add(carList.get(i).getCarType());
    }
    public void noCarsAvailable(){
        noCars.setText("Sorry no cars match your choices");
        noCars.setVisibility(View.VISIBLE);
        carSP.setVisibility(View.INVISIBLE);
        img1.setVisibility(View.INVISIBLE);
        img2.setVisibility(View.INVISIBLE);
        img3.setVisibility(View.INVISIBLE);
        img4.setVisibility(View.INVISIBLE);
        img5.setVisibility(View.INVISIBLE);
        priceLabel.setVisibility(View.INVISIBLE);
        price.setVisibility(View.INVISIBLE);
        millageLable.setVisibility(View.INVISIBLE);
        millage.setVisibility(View.INVISIBLE);
        carsLabel.setVisibility(View.INVISIBLE);

    }
    public void casrAvailable(){
        noCars.setVisibility(View.INVISIBLE);
        carSP.setVisibility(View.VISIBLE);
        img1.setVisibility(View.VISIBLE);
        img2.setVisibility(View.VISIBLE);
        img3.setVisibility(View.VISIBLE);
        img4.setVisibility(View.VISIBLE);
        img5.setVisibility(View.VISIBLE);
        priceLabel.setVisibility(View.VISIBLE);
        price.setVisibility(View.VISIBLE);
        millageLable.setVisibility(View.VISIBLE);
        millage.setVisibility(View.VISIBLE);
        carsLabel.setVisibility(View.VISIBLE);
    }

    public Car getCarObject(String name){
        for(int i=0;i<carList.size();i++)
            if(name.equals(carList.get(i).getCarType()))
                return carList.get(i);
        return null;
    }
}
