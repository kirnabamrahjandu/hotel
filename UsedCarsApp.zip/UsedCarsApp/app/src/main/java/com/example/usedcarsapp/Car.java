package com.example.usedcarsapp;

import java.util.ArrayList;

public class Car {
    private String carMake;
    private String carType;
    private int year;
    private int millage;
    private double price;
    private ArrayList<String>carImages;

    public String getCarMake() {
        return carMake;
    }

    public String getCarType() {
        return carType;
    }

    public int getYear() {
        return year;
    }

    public int getMillage() {
        return millage;
    }

    public double getPrice() {
        return price;
    }

    public ArrayList<String> getCarImages() {
        return carImages;
    }

    public Car(String carMake, String carType, int year, int millage, double price, ArrayList<String> carImages) {
        this.carMake = carMake;
        this.carType = carType;
        this.year = year;
        this.millage = millage;
        this.price = price;
        this.carImages = carImages;

    }
}
